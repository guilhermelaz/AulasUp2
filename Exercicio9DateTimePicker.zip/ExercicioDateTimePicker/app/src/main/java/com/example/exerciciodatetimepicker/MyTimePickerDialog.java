package com.example.exerciciodatetimepicker;

import android.app.Dialog;
import android.app.TimePickerDialog;
import android.os.Bundle;
import android.widget.TimePicker;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.DialogFragment;

public class MyTimePickerDialog extends DialogFragment implements TimePickerDialog.OnTimeSetListener {


    @NonNull
    @Override
    public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {
        return new TimePickerDialog(getActivity(), this, 21, 20, true);
    }

    @Override
    public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
        String msg = String.format("%02d:%02d", hourOfDay, minute);
        Bundle bundle = new Bundle();
        bundle.putString("bundleKey", msg);
        getParentFragmentManager().setFragmentResult("timeKey", bundle);
//        Toast.makeText(getActivity(), msg, Toast.LENGTH_SHORT).show();
    }
}
