from unique1 import get_only_unique_words_from_text


#Palava chungos existe 2 vezes no texto
def test_unique_words():    
    assert "chungus" not in get_only_unique_words_from_text()
    assert "allan" in get_only_unique_words_from_text()


#Palavra allan existe 1 vez no texto
#def test_unique_words1():
#    assert "allan" in get_only_unique_words_from_text()
