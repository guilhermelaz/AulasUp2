from hashing_passwords import hash_password

def test_hash_password():
    assert hash_password('senhabolada', 'sha256') == 'e961d9114eb79dcbd4e75d3c8643798d6ee815abe33bedd4d863aa787e73e65c'
    assert hash_password('senhabolada', 'sha512') == 'f925605aad1a74b42a2484fb1c03e6ec2f202a7e2dce797eec7728b16c700ca82e54686f014c4f6491f02b89b4280ea9a306704b7e291b887e2e3e6e6f02e62a'
    assert hash_password('senhabolada', 'md5') == 'ba4db3e572ed23675cf4107a1774f916'

    assert hash_password('senhabolada', 'sha256') != 'e961d9114eb79'
    assert hash_password('senhabolada', 'sha512') != 'f925605aad1a74b42a2484fb1c03e6ec2f202a7e2dce797eec7728b16c700ca82e54686f014c4f6491f02b89b4280ea9a306704b7e291b887e2e3e6e6f02e62'
    assert hash_password('senhabolada', 'md5') != 'ba4db3e572ed23675cf4107a1774f91'