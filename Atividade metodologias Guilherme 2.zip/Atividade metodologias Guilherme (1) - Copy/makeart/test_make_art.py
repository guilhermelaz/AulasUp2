
import cv2
import make_art


def test_image_to_ascii_dont_have_letters():
    imagemAscii = make_art.img_to_ascii(cv2.imread("makeart/sample_image.png", 0))
    assert "A" not in imagemAscii 
    #assert str(imagemAscii).__contains__("4")

def test_image_to_ascii_have_number():
    imagemAscii = make_art.img_to_ascii(cv2.imread("makeart/sample_image.png", 0))
    assert str(imagemAscii).__contains__("4")