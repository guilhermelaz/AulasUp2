from generate_qrcode import generate_qrcode, get_qrcode_fromImage
import qrcode
from PIL import Image
import numpy as np
import os

def test_generate_qrcode():
    generate_qrcode("https://www.google.com/", "qrcode/test_qrcode.png")
    img1 = Image.open("qrcode/test_qrcode.png")
    img2 = Image.open("qrcode/qrgoogle.png")
    assert np.array_equal(np.array(img1), np.array(img2))

def test_qrcode_file_created():
    filename = "qrcode/test_simple_qrcode.png"
    generate_qrcode("https://www.example.com/", filename)

    assert os.path.exists(filename)


# def test_qrcode_file_NON_existent():
#     filename_errado = "qrcode/test_simple_qrcode_errado.png"
#     assert not os.path.exists(filename_errado)
