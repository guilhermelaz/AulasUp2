from reduceimage import reduce_image

def test_reduce_image():
    assert reduce_image("reduceimage/input.jpg") == "Ok"
    # se a imagem não existir
    assert reduce_image("reduceimage/input2.jpg") == "Sem input"