package com.example.exerciciodatetimepicker;

import android.app.DatePickerDialog;
import android.app.Dialog;
import android.os.Bundle;
import android.widget.DatePicker;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.DialogFragment;

import java.util.Locale;

public class MyDatePickerDialog extends DialogFragment implements DatePickerDialog.OnDateSetListener {

    @NonNull
    @Override
    public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {
        return new DatePickerDialog(getActivity(), this, 2024, 7, 30);
    }

    // Enviar bundle
    @Override
    public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
        String msg = String.format(new Locale("pt", "BR"), "%02d/%02d/%d", dayOfMonth, month + 1, year);
        Bundle bundle = new Bundle();
        bundle.putString("bundleKey", msg);
        getParentFragmentManager().setFragmentResult("dateKey", bundle);
        Toast.makeText(getActivity(), msg, Toast.LENGTH_SHORT).show();
    }

}
