package com.example.exerciciodatetimepicker;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentResultListener;

import com.example.exerciciodatetimepicker.databinding.ActivityMainBinding;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    private ActivityMainBinding binding;
    private TextView tvDateTime;
    private TextView tvDateTime2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        tvDateTime = binding.tvDateTime;
        tvDateTime2 = binding.tvDateTime2;
        Button buttonDate = binding.btnSetDate;
        Button buttonTime = binding.btnSetTime;

        buttonDate.setOnClickListener(this);
        buttonTime.setOnClickListener(this);

        getSupportFragmentManager().setFragmentResultListener("dateKey", this, new FragmentResultListener() {
            @Override
            public void onFragmentResult(String requestKey, Bundle result) {
                String date = result.getString("bundleKey");
                tvDateTime.setText(date);
            }
        });

        getSupportFragmentManager().setFragmentResultListener("timeKey", this, new FragmentResultListener() {
            @Override
            public void onFragmentResult(String requestKey, Bundle result) {
                String time = result.getString("bundleKey");
                tvDateTime2.setText(time);
            }
        });
    }

    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.btnSetDate) {
            MyDatePickerDialog myDatePickerDialog = new MyDatePickerDialog();
            myDatePickerDialog.show(getSupportFragmentManager(), "datepick");
        }
        if (v.getId() == R.id.btnSetTime) {
            MyTimePickerDialog myTimePickerDialog = new MyTimePickerDialog();
            myTimePickerDialog.show(getSupportFragmentManager(), "timepick");
        }
    }
}