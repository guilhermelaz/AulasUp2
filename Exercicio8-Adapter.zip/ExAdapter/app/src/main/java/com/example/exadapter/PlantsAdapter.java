package com.example.exadapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class PlantsAdapter extends RecyclerView.Adapter<PlantsAdapter.ViewHolder> {

    private List<Plants> localDataSet;

    public PlantsAdapter(List<Plants> localDataSet) {
        this.localDataSet = localDataSet;
    }

    @NonNull
    @Override
    public PlantsAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(
                R.layout.text_row_item, parent, false
        );

        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull PlantsAdapter.ViewHolder holder, int position) {
        Plants plants = localDataSet.get(position);
        holder.getTextView().setText(plants.name);
        holder.getImageView().setImageResource(plants.img);
        holder.getSunCost().setText(plants.sunCost);
    }

    @Override
    public int getItemCount() {
        return localDataSet.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        private final TextView textView;
        private final ImageView imageView;
        private final TextView sunCost;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            textView = (TextView) itemView.findViewById(R.id.txtNomeConsole);
            imageView = (ImageView) itemView.findViewById(R.id.imgConsole);
            sunCost = (TextView) itemView.findViewById(R.id.txtSunCost);
        }

        public TextView getTextView(){
            return textView;
        }

        public TextView getSunCost(){
            return sunCost;
        }

        public ImageView getImageView(){
            return imageView;
        }
    }

}