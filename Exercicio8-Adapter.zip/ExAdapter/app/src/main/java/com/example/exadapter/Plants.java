package com.example.exadapter;

import java.util.ArrayList;
import java.util.List;

public class Plants {

    public String name;
    public String sunCost;
    public int img;

    public Plants(String name, int img, String cost) {
        this.name = name;
        this.img = img;
        this.sunCost = cost;
    }

    public static List<Plants> getConsoles(){
        List<Plants> plants = new ArrayList<>();
        plants.add(new Plants("PeaShoter", R.drawable.peashoter, "Sun Cost: 100"));
        plants.add(new Plants("Carnivor", R.drawable.carnivor, "Sun Cost: 150"));
        plants.add(new Plants("Mine", R.drawable.mine, "Sun Cost: 25"));
        plants.add(new Plants("IcePeaShoter", R.drawable.icepeashoter, "Sun Cost: 175"));
        plants.add(new Plants("SunFlower", R.drawable.sunflower, "Sun Cost: 50"));
        return plants;
    }
}
